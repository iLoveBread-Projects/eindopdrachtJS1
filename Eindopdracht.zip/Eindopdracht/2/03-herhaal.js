// Functions
function toonTekst() {
    for(i = 1; i < 7; i++) {
        document.write(`<p>Herhaling: ${i}</p>`);
    }
}